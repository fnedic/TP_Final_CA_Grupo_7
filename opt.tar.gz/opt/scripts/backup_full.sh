#! /bin/bash

#Informacion:
# $0 corresponde al nombre del script
# $1 corrrsponde al 1er parametro pasado al script
# $2 corresponde al 2do parametro pasado al script


############### INICIO DEL SCRIPT ###############

# Funcion de ayuda
# Al terminar el script con un exit 1, indicamos un error o una condicion especial
# Esta funcion la podremos llamar mas adelante segun necesitemos
function help() {
	echo ""
	echo "--------------- INSTRUCCIONES DE USO ---------------"
	echo ""
	echo " root@debian: $0 [origen] [destino]          "
	echo "                                         "
	echo "   [origen]  - Directorio origen a respaldar"
	echo "   [destino] - Directorio destino del backup"
	echo ""
	echo " Opciones:"
	echo ""
	echo "   -h      - Mostrar ayuda"
	echo ""
	echo "----------------------------------------------------"
	echo ""
	exit 1
}

# Validamos la opcion de ayuda
# Con esto nos aseguramos que si el usuario ejecuta nombre_script.sh -h, este
# condicional nos devolvera la funcion help, indicandonos como usar el script.
if [ "$1" == "-h" ]; then
	help
fi

# Validamos los numeros de argumentos
# $# nos devuelve el numero de argumentos totales
# Usamos -ne (distinto que) para entrar al condicional si 
# el numero total de argumento es distinto a 2
if [ $# -ne 2 ]; then
	echo "Error: numero incorrecto de argumentos"
	help
fi

#Si todo esta bien, asignamos los argumentos a las variables
FROM="$1"
TO="$2"
FILE_NAME="$(basename "$FROM")_bkp_$(date +%Y%m%d).tar.gz"

# Validamos que el directorio de origen exista y se encuentre montado
# Usamos el argumento -d que nos arroja si el path a evaluar es un directorio valido
# Si el directorio no es valido salimos del script
if [ ! -d "$FROM" ]; then
	echo "ERROR - El directorio de origen $FROM no existe"
	exit 1
fi
# Validamos que el directorio de origen este montado

if [ "$FROM" == "/www_dir" ]; then
	if ! grep -qs "$FROM" /etc/mtab ; then
		echo "ERROR - El directorio de origen $FROM no se encuentra montado"
		exit 1
	fi
fi
# Hacemos la misma validacion para el directorio de destino
if [ ! -d "$TO" ]; then
	echo "ERROR - El directorio de destino $TO no existe"
	exit 1
fi
if ! grep -qs "$TO" /etc/mtab ; then
	echo "ERROR - El directorio de destino $TO no se encuentra montado"
	exit 1
fi

# Si ambos direcotrios son correctos y se encuentran montados:
# Realizamos el backup (tar crea un archivo comprimido .tar.gz)
# -> czf crea un nuevo archivo tar (c), comprime el archivo (z) y especifica el nombre (f)
# -> -C permite que tar cambie al directorio especificado antes de realizar la operacion de archivado
# -> dirname nos asegura de extraer el contenido a empaquetar sin incluir la ruta completa
# -> basename nos permite extraer el nombre del dir. de origen, que se incluira en
# el archivo tar
tar -czf "$TO/$FILE_NAME" -C "$(dirname "$FROM")" "$(basename "$FROM")"

# Verificamos el resultado del backup
# -> $? hace referencia al codigo de salida del ultimo comando ejecutado del script
# -> Si el codigo es 0, el script es exitoso, por lo tanto se realizo el backup
# -> Si no es asi, se imprime un mensaje de error
if [ $? -eq 0 ]; then
	echo "EXITO - Backup realizado exitosamente! --> $TO/$FILE_NAME :)"
else
	echo "ERROR - Algo fallo al realizar el backup :("
	exit 1
fi
